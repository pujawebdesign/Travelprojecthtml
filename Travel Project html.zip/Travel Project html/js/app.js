jQuery('.nav-toggle').on('click', function() {
    jQuery(this).toggleClass('open');
    jQuery('.menu').toggleClass('collapse');
  });